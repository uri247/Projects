#include "stdafx.h"

#pragma comment(lib, "setupapi.lib")

