#pragma once

// C++ headers
#include <iostream>
#include <iomanip>
#include <string>

// Windows headers
#define WIN32_LEAN_AND_MEAN    1
#define _WIN32_WINNT           0x0501
#include <Windows.h>
#include <SetupAPI.h>

