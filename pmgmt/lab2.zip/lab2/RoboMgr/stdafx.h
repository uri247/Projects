
// CRT
#include <cstdlib>
#include <exception>
#include <system_error>
#include <iostream>
#include <iomanip>
#include <memory>


// windows
#define _WIN32_WINNT            0x0601
#define WIN32_LEAN_AND_MEAN     1
#include <windows.h>
#include <SetupAPI.h>
#include <winioctl.h>


